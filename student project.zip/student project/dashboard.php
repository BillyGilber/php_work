<?php 
session_start();
if(!isset($_SESSION['user'])){
    header("location:index.php");
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav>
    <ul>
        <li><a href="addstudent.php">Addstudent</a></li>
        <li><a href="display.php">display</a></li>
        <li><a href="logout.php">logout</a></li>
    </ul>
</nav>
    
</body>
</html>