

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";




CREATE TABLE `addstudent` (
  `student_id` int(11) NOT NULL,
  `firstname` varchar(10) DEFAULT NULL,
  `lastname` varchar(15) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `department` varchar(15) DEFAULT NULL,
  `gender` enum('male','female') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;


INSERT INTO `addstudent` (`student_id`, `firstname`, `lastname`, `age`, `department`, `gender`) VALUES
(4, 'ishimwe', 'cadette', 13, 'it', '');



CREATE TABLE `users` (
  `user_id` int(10) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;



INSERT INTO `users` (`user_id`, `username`, `password`) VALUES
(1, 'nancy', '123'),
(2, 'bruno', '345'),
(3, 'bruce', '456');


ALTER TABLE `addstudent`
  ADD PRIMARY KEY (`student_id`);


ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);


ALTER TABLE `addstudent`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

ALTER TABLE `users`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

